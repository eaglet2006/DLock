**Project Description**
DLock is a distributed lock component base on .net framework. It provide a set of distributed locks including Exclusive lock , Shared lock, Monitor, and provide a tools can be used to monitor the distributed locks.
